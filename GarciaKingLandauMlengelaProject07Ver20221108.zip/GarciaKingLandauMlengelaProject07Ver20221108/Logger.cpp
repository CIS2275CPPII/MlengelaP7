/****************************************************************
* Programmers: Aaron Garcia, Carrah King, Mayer Landau, Daudi Mlengela,
* Email: agarcia1091@cnm.edu, aking22@cnm.edu, mlandau1@cnm.edu, dmlengela@cnm.edu
* Project 07: Black Jack
* File: Logger.cpp
*****************************************************************/

#include "Logger.h"

using namespace std;


Logger::Logger()
{
	FileName();
	Time();
		output.open(filename.c_str());
		if (!output)
		{
			bLogOpen = false;
		}
		else
			bLogOpen = true;
	output << "\n\n This is the log of your Blackjack games"
		<< "\n\n Time:  " << timeRightNow;
}

void Logger::StartLog(double initialB)
{
	output << "   Starting with $ " << initialB << ".";
}

void Logger::WriteLog(string s)
{
	Time();
	output << "\n\n Time: " << timeRightNow;
	output << s;
}

void Logger::CloseLog(string s)
{
	output << s;
	output.close();
	string openfile = "notepad.exe " + filename;
	system(openfile.c_str());
}

void Logger::FileName()
{
	auto now = std::chrono::system_clock::now();
	auto in_time_t = std::chrono::system_clock::to_time_t(now);
	struct tm ptm;
	localtime_s(&ptm, &in_time_t);

	std::stringstream ss;
	ss << std::put_time(&ptm, "%m-%d-%Y_%I.%M.%S");
	dateTimeStamp = ss.str();
	cout << "\n" << dateTimeStamp << "  ";

	filename = "Log_" + dateTimeStamp + ".txt";
}

void Logger::Time()
{
	auto now = std::chrono::system_clock::now();
	auto in_time_t = std::chrono::system_clock::to_time_t(now);
	struct tm ptm;
	localtime_s(&ptm, &in_time_t);

    std:stringstream ss;
	ss << std::put_time(&ptm, "%X");
	timeRightNow = ss.str();
	cout << "\n " << timeRightNow;
}

