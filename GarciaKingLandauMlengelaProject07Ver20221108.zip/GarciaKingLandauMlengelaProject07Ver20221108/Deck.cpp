/****************************************************************
* Programmers: Aaron Garcia, Carrah King, Mayer Landau, Daudi Mlengela,
* Email: agarcia1091@cnm.edu, aking22@cnm.edu, mlandau1@cnm.edu, dmlengela@cnm.edu
* Project 07: Black Jack
* File: Deck.cpp
*****************************************************************/

#include "Deck.h"


using namespace std;


//------------------------------------
//default constructor, seeds random engine
// and inits the cards[] array
//------------------------------------
Deck::Deck() : 
	cards{ 0,1,2,3,4,5,6,7,8,9,10,11,12,13,
	14,15,16,17,18,19,20,21,22,23,24,25,26,
	27,28,29,30,31,32,33,34,35,36,37,38,39,
	40,41,42,43,44,45,46,47,48,49,50,51 }
{
	//SEEDING FOR RANDOM GENERATOR
	// Testing the seed
	//srand((unsigned)time(NULL)); //old random rand() seeder
	//engine.seed(123);
	
	engine.seed(chrono::system_clock::now().time_since_epoch().count());
	
}



//-------------------------------------------PUBLIC-------------------------------------------

//------------------------------------
//method shuffles the deck 
//  Fisher-Yates algorithm to shuffle the deck
//------------------------------------
void Deck::Shuffle()
{

	for (int i = 0; i < 52; i++)
	{
		int r = RandomCard();
		swap(cards[i], cards[r]);
	}

}



//------------------------------------
//method returns a random integer by using the 
// uniform_int_distribution in the range of 0 - 51.
//------------------------------------
int Deck::RandomCard()
{
	uniform_int_distribution<unsigned int> card(0, 51);
	
	return card(engine);
}



//------------------------------------
//method is used to deal a card off the top of the deck. 
// It passes a Card object by reference. 
//  
// It uses the topCard variable as an index of the cards[] array for instantiating a new Card object, 
// then setting the reference passed in to the new card object.   
// 
// The topCard variable starts at 0 and is incremented until it is greater than 34, 
// indicating that the remaining 17 cards could possibly use up the rest of the deck on the next hand.  
// 
// In this case, the deck is re-shuffled and topCard is again set to 0.  
//------------------------------------
void Deck::Deal(Card& c)
{
	// We use the overloaded constructer to
	// set all the values the Card c.
	// Here cards in the Deck class is an array of integers.
	// Not to be confused with cards in the Hand class which is an array of Cards.
	Card tempCard(cards[topCard]); 
	c = tempCard;

	++topCard;
	if (topCard > 34)
	{
		Shuffle();
		topCard = 0;
	}
}

// These functions can be added to test for black jack
/*void Deck::SpecialDeal01(Card& c)
{
	Card tempCard(0);
	c = tempCard;
}

void Deck::SpecialDeal02(Card& c)
{
	Card tempCard(10);
	c = tempCard;
}*/
