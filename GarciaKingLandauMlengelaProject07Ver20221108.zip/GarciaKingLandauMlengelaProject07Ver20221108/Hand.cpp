/****************************************************************
* Programmers: Aaron Garcia, Carrah King, Mayer Landau, Daudi Mlengela,
* Email: agarcia1091@cnm.edu, aking22@cnm.edu, mlandau1@cnm.edu, dmlengela@cnm.edu
* Project 07: Black Jack
* File: Hand.cpp
*****************************************************************/

#include "Hand.h"
using namespace std;


//It takes an object of the Card class as an argument 
// and adds it to the first available position within 
// the cards[] array.  It then increments numCards .
//------------------------------------
void Hand::AddCard(Card c)
{
	if (numCards < MAX_CARDS)
	{
		cards[numCards] = c;
	}
	else
	{
		ClearHand();
		cards[numCards] = c;
	}
	
	//increment numCards
	++numCards;
}

//------------------------------------
//Displays either the dealer�s or the player�s hand.  
// 
// The first card of the dealer�s hand should be hidden 
// until the player �stays� and the dealer plays his hand.  
// 
// The method returns a string which contains the title of 
// Dealer or Player and lists the cards in the hand.
//------------------------------------
string Hand::Show(bool isDealer, bool hideFirstCard)
{
	ostringstream uHand, dHand;
	string suit;
	;


	//do for dealer AND for player, with if else
	if (!isDealer)
	{
		for (int i{ 0 }; i < numCards; i++)
		{
			int cNum{ i + 1 };
			uHand << "\r\n*Card# " << cNum << ": " << cards[i].GetValue() << " of ";

			if (cards[i].GetSuit() == "S")
			{
				suit = "Spades";
			}
			else if (cards[i].GetSuit() == "H")
			{
				suit = "Hearts";
			}
			else if (cards[i].GetSuit() == "C")
			{
				suit = "Clubs";
			}
			else
			{
				suit = "Diamonds";
			}

			uHand << suit << endl;

		}

		return showHand = uHand.str();
	}
	else
	{
		if (!hideFirstCard)
		{
			for (int i{ 0 }; i < numCards; i++)
			{
				int cNum{ i + 1 };
				dHand << "\r\n*Card# " << cNum << ": " << cards[i].GetValue() << " of ";

				if (cards[i].GetSuit() == "S")
				{
					suit = "Spades";
				}
				else if (cards[i].GetSuit() == "H")
				{
					suit = "Hearts";
				}
				else if (cards[i].GetSuit() == "C")
				{
					suit = "Clubs";
				}
				else
				{
					suit = "Diamonds";
				}

				dHand << suit << endl;
			}

			return showHand = dHand.str();
			
		}
		else
		{
			for (int i{ 0 }; i < numCards; i++)
			{				
				int cNum{ i + 1 };
				if (i == 0)
				{
					dHand << "\r\n*Card# " << cNum << ": ?HIDDEN?" << endl;
				}
				else
				{

					dHand << "\r\n*Card# " << cNum << ": " << cards[i].GetValue() << " of ";

					if (cards[i].GetSuit() == "S")
					{
						suit = "Spades";
					}
					else if (cards[i].GetSuit() == "H")
					{
						suit = "Hearts";
					}
					else if (cards[i].GetSuit() == "C")
					{
						suit = "Clubs";
					}
					else
					{
						suit = "Diamonds";
					}

					dHand << suit << endl;
				}
			}

			return showHand = dHand.str();
		}

	}

}


//------------------------------------
//Checks if the hand is BlackJack and returns true or false.  
// It also checks if the number of cards in the hand = 2.
//  
// It has to be 2 cards for BlackJack.  The player wins 1.5 * bet.
//------------------------------------
bool Hand::BlackJack()
{
	bool yesBlackJack = false;

	if (numCards == 2)
	{
		if (      (cards[1].GetIValue() == 1)
			  &&  (  (cards[0].GetValue() == "King") 
			      || (cards[0].GetValue() == "Queen")  
			      || (cards[0].GetValue() == "Jack")   )  
			||    ((cards[0].GetIValue() == 1)
			  &&  ( (cards[1].GetValue() == "King") 
				  || (cards[1].GetValue() == "Queen")
				  || (cards[1].GetValue() == "Jack")))		
			)
		{
			yesBlackJack = true;
		}
	}
	return yesBlackJack;
}


//------------------------------------
//Checks whether the number of points in a hand is less than the number n, 
// that is passed in as an argument. 
//  
// It sums the points in the hand and adds up the iValue of each card.
//------------------------------------
bool Hand::Under(int a)
{
	int sum{ 0 };

	for (int i = 0; i < MAX_CARDS; i++) {
		sum += cards[i].GetIValue();
	}

	//If hand is < a, set busted false
	if (sum < a)
	{
		return true;
	}
	else
	{
		return false;
	}

}



//------------------------------------
//Returns an integer identifying the best possible score for the hand.  
// It adjusts the value associated with aces to either 1 or 11, 
// depending on whether it causes the hand to go over 21 points.  
// 
// It uses a variable, haveAce, of type bool, to identify whether the hand contains an ace.It uses a for statement to calculate 
// the minimum number of points in the handand to determine if any aces are present.If an ace is found, it determines whether it 
// is better to use the 11 or 1 point value of the ace.
//------------------------------------
int Hand::BestScore()
{
	bool haveAce{ false };
	//check if hand has an Ace, if so, check its value, set ace 11
	for (int i{ 0 }; i < numCards; ++i)
	{
		if (cards[i].GetIValue() == 1)
		{
			haveAce = true;
			break;
		}
	}

	if (haveAce)
	{
		int sum{ 0 }, check{ 0 };

		for (int i = 0; i < MAX_CARDS; i++) {
			sum += cards[i].GetIValue();
		}

		check = (sum - 1) + 11;
		
		if (check < 22)//if 11 ok, return that it is 11
		{
			return check;
		}
		else//if that busts, set ace to 1
		{
			return sum;
		}
			
	}
	else if (!haveAce) {
		int sum{ 0 };
		for (int i = 0; i < MAX_CARDS; i++) {
			sum += cards[i].GetIValue();
		}
		return sum;
	}
}

//------------------------------------
//Checks the dealer�s hand to see if the hand is less than 17.  
// 
// If it is, the dealer must hit.  
// If it is 17 or higher, the dealer must stay.
//------------------------------------
bool Hand::MustHit()
{		
	//if dealer's best score is <17. they MUST hit
	if (BestScore() < 17)
	{
		return true;
	}
	else
	{
		return false;
	}
}



//------------------------------------
//Checks if the number of points in a hand is under 22.  
// If not, the hand is busted and returns true.
//------------------------------------
bool Hand::Busted()
{
	//If hand is < 22, set busted false
	if (Under(22))
	{
		return false;
	}
	else
	{
		return true;
	}

}



//------------------------------------
//sets showHand  to �� and numCards = 0.
//------------------------------------
void Hand::ClearHand()
{
	//sets ShowHand to "" and numCards to 0
	showHand = "";
	for (int i = 0; i < MAX_CARDS; i++) 
	{
		// Set the cards array all to zero
		Card tempCard;
		cards[i] = tempCard;
		//cards[i] = 0;
	}
	numCards = 0;
	Card temp1 = cards[0];
	Card temp2 = cards[1];
	Card temp3 = cards[3];

}
