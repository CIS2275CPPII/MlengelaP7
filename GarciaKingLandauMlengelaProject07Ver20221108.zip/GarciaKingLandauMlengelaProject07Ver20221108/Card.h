/****************************************************************
* Programmers: Aaron Garcia, Carrah King, Mayer Landau, Daudi Mlengela,
* Email: agarcia1091@cnm.edu, aking22@cnm.edu, mlandau1@cnm.edu, dmlengela@cnm.edu
* Project 07: Black Jack
* File: Card.h
*****************************************************************/

#ifndef CARD_H
#define CARD_H

#include<string>
#include<string>
using namespace std;

class Card
{
    //member variables
private:
    int  iValue{ 0 }; //numeric value corresponding to the card
    string value =""; // "Ace" "2" through "9", "Ten", "Jack", "Queen", "King"
    string suit =""; //"S", "H", "C", "D"

public:

    Card(){} // default constructor
    Card(int n); // Overloaded constructor. The heart of the card class
    void SetIValue(int val) { iValue = val;}
    string GetValue() { return value; }
    int GetIValue() { return iValue; }
    string GetSuit() { return suit; }
};
#endif

