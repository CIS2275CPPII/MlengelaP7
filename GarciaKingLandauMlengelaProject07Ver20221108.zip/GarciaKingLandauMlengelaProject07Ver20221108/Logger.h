#ifndef LOGGER_H
#define LOGGER_H

#include <string>
#include <sstream>
#include <fstream>
#include <iomanip>
#include <ctime>
#include <chrono>
#include <iostream>

using namespace std;

class Logger
{
private:
	string filename;	// The Filename method will create the filename.  It will make the filename with a date and time stamp.
	string timeRightNow;  //A string to be used as a time stamp in the constructor and for each play.
	string dateTimeStamp;  //a string making up part of the Log filename 
	bool bLogOpen{ true }; //to ensure the log is opened.

	ofstream output;     //will be a class member, since the file will be written into repeatedly
	void Time();  // gets time string for timeRightNow.  Uses chrono and the system_clock.
	void FileName();  //Creates the filename using dateTimeRightNow in this format: Log_month_day_year_hour_minute_second.txt or Log_ dateTimeRightNow.txt	
public:
	Logger();
	void StartLog(double initialBal); //writes the initial lines of the log file.A double is passed in.
	void WriteLog(string s); // writes into the log file any time a game is completed.
	void CloseLog(string s); //writes the message from the EndGame() functionand closes the file.
	bool IsLogOpen() { return bLogOpen; };// so the log success can be checked by the Game class.
};


#endif 

