/****************************************************************
* Programmers: Aaron Garcia, Carrah King, Mayer Landau, Daudi Mlengela, 
* Email: agarcia1091@cnm.edu, aking22@cnm.edu, mlandau1@cnm.edu, dmlengela@cnm.edu
* Project 07: Black Jack
* File: MyForm.cpp
*****************************************************************/


#include "MyForm.h"


using namespace System;

using namespace System::Windows::Forms;



[STAThread]

void Main()

{

	Application::EnableVisualStyles();

	Application::SetCompatibleTextRenderingDefault(false);


	GarciaKingLandauMlengelaP07::MyForm form;

	Application::Run(% form);

}
