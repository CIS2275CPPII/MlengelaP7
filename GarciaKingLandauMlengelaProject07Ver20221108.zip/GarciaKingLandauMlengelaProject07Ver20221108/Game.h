/****************************************************************
* Programmers: Aaron Garcia, Carrah King, Mayer Landau, Daudi Mlengela,
* Email: agarcia1091@cnm.edu, aking22@cnm.edu, mlandau1@cnm.edu, dmlengela@cnm.edu
* Project 07: Black Jack
* File: Game.h
*****************************************************************/

#ifndef GAME_H
#define GAME_H

#include "Hand.h"
#include "Deck.h"
#include "Logger.h"
#include <string>
#include <sstream>

using namespace std;


class Game
{
private:
	int bet{ 0 }, numberOfBets{ 0 };
	int wins{ 0 }, losses{ 0 }, ties{ 0 };
	double money{ 1000.0 }, initialMoney{ 1000.0 };
	Deck deck;
	Hand playersHand;
	Hand dealersHand;
	Logger log;

public:
	Game();
	bool IsLogOpened() { return log.IsLogOpen(); }
	bool setBet(int b);
	void InitialDeal();
	string ShowPlayerHand() 
	{
		return playersHand.Show(false, false);
	}

	string ShowDealerHand(bool hide)
	{
		return dealersHand.Show(true, hide);
	}
	bool IsBlackJack() { return playersHand.BlackJack(); }
	bool PlayerBusted() { return playersHand.Busted(); }
	void PlayerHits();
	bool PlayerContinues();
	bool DealerContinues();
	string PlayerWins();
	string DealerWins();
	string Tie();
	string ShowResults();
	string NoResults() { return "No results"; }
	void ClearHands();
	void EndGame();


};

#endif