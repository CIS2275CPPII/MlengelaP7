/****************************************************************
* Programmers: Aaron Garcia, Carrah King, Mayer Landau, Daudi Mlengela,
* Email: agarcia1091@cnm.edu, aking22@cnm.edu, mlandau1@cnm.edu, dmlengela@cnm.edu
* Project 07: Black Jack
* File: Game.cpp
*****************************************************************/

#include "Game.h"
#include "Card.h"

//passes the log the initial money for the player
Game::Game()
{
	log.StartLog(money);
	
}
//sets the bet into the class. check that the bet is not < 1 or >
//the form event handler will display an invalid bet and tell the user.
bool Game::setBet(int b)
{
	if (!(b <= 0) && !(b > money))
	{
		bet = b;
		return true;
	}
	return false;
}


//two cards are dealt to the player and the dealer
//create one card object or two if you prefer.
//pass it the the deck.deal method
// add it to the player's hand or dealer's hand,
// whichever you are dealing to at the moment
//maybe use a short for a loop to deal two each
void Game::InitialDeal()
{
	deck.Shuffle();
	Card card;
	
	// If you want to test special deals, such as black jack
	/*deck.SpecialDeal01(card);
	playersHand.AddCard(card);
	deck.SpecialDeal02(card);
	playersHand.AddCard(card);*/
	
	for (int i = 0; i < 2; i++)
	{
		deck.Deal(card);
		playersHand.AddCard(card);
		deck.Deal(card);
		dealersHand.AddCard(card);
	}
}

//deal one card to the player
void Game::PlayerHits()
{
	Card card;
	deck.Deal(card);
	playersHand.AddCard(card);
}

//check if the player has busted, if not return true
bool Game::PlayerContinues()
{
	if (!playersHand.Busted()) { return true; }
	return false;
}

//check if the dealer must hit, if so deal the dealer a card
bool Game::DealerContinues()
{
	if (dealersHand.MustHit())
	{
		Card card;
		deck.Deal(card);
		dealersHand.AddCard(card);
		return true;
	}
	return false;
}

//if it is Blackjack, money won is 1.5 x bet otherwise just the bet
//create a string that is written into the log
string Game::PlayerWins()
{
	stringstream ss;
	ss << "     Player Wins Hand! ";
	if (playersHand.BlackJack() == true)
	{
		money += bet * 1.5;
		ss << " Player Black Jack!";
	}
	else
	{
		money += bet;	
	}
	ss << "\r\nBet: $" << bet << " \r\nPlayer: $" << money 
		<< "\r\nWins: " << wins << "     Losess: " << losses 
		<< "     Ties: " << ties << "     Bets: " << numberOfBets;
	log.WriteLog(ss.str());
	return ss.str();
}

//similar to player wins, but says player loses.
string Game::DealerWins()
{
	stringstream ss;
	ss << "     Dealer Wins Hand! ";
	if (dealersHand.BlackJack() == true)
	{
		ss << "   Dealer Black Jack!";
	}
	money -= bet;
	ss << "\r\nBet: $" << bet << " \r\nPlayer: $" << money 
		<< "\r\nWins: " << wins << "     Losess: " << losses 
		<< "     Ties: " << ties << "     Bets: " << numberOfBets;
	log.WriteLog(ss.str());
	return ss.str();
}

string Game::Tie()
{
	stringstream ss;
	ss << "     Tie Game!\r\nBet: $" << bet << " \r\nPlayer: $" << money 
		<< "\r\nWins: " << wins << "     Losess: " << losses 
		<< "     Ties: " << ties << "     Bets: " << numberOfBets;
	log.WriteLog(ss.str());
	return  ss.str();
}

//Returns a string of the game results and adjusts game state to reflect results.
string Game::ShowResults()
{
	string s;
	numberOfBets++;
	int playersBestScore = playersHand.BestScore();
	int dealersHandBestScore = dealersHand.BestScore();
	//According to blackjack, if both player and dealer busts, player loses.
	if (playersHand.Busted()) 
	{ 
		losses++;
		s = DealerWins();

	}
	else if (dealersHand.Busted())
	{
		wins++;
		s = PlayerWins();
	}
	else if (playersBestScore > dealersHandBestScore)
	{
		wins++;
		s = PlayerWins();
	}
	else if (playersBestScore < dealersHandBestScore)
	{
		losses++;
		s = DealerWins();
	}
	else if (playersBestScore == dealersHandBestScore)
	{
		ties++;
		s = Tie();
	}
	else
	{
		s = NoResults();
	}

	return s;
}

void Game::ClearHands()
{
	dealersHand.ClearHand();
	playersHand.ClearHand();
}

void Game::EndGame()
{
	stringstream ss;
	ss << "    \r\nFinal Results  --  Player $: " << money;
	log.CloseLog(ss.str());
}
