/****************************************************************
* Programmers: Aaron Garcia, Carrah King, Mayer Landau, Daudi Mlengela,
* Email: agarcia1091@cnm.edu, aking22@cnm.edu, mlandau1@cnm.edu, dmlengela@cnm.edu
* Project 07: Black Jack
* File: Deck.h
*****************************************************************/

#ifndef _DECK_H
#define _DECK_H

#include "Card.h"

#include <iostream>
#include <array>
#include <random>
#include <chrono>


using namespace std;


//#pragma once
class Deck
{
private:
	array <int, 52>  cards;	//array of 52 cards
	int topCard{ 0 };	//0-51, index of the next card to be dealt
	default_random_engine engine;	//Creates an object of the random engine 

public:
	Deck();
	void Shuffle();
	int RandomCard();
	void Deal(Card& c);

};

#endif // !_DECK_H