/****************************************************************
* Programmers: Aaron Garcia, Carrah King, Mayer Landau, Daudi Mlengela,
* Email: agarcia1091@cnm.edu, aking22@cnm.edu, mlandau1@cnm.edu, dmlengela@cnm.edu
* Project 07: Black Jack
* File: Hand.h
*****************************************************************/

#ifndef _HAND_H
#define _HAND_H

#include "Card.h"


#include <iostream>
#include <array>
#include <sstream>
//#include <numeric>


using namespace std;


const int MAX_CARDS{ 12 };

//#pragma once
class Hand
{
private:
	int numCards{ 0 }; //number of cards in the hand.
	string showHand;
	array<Card, MAX_CARDS> cards;

public:
	Hand() = default;
	void AddCard(Card c);
	string Show(bool isDealer, bool hideFirstCard);
	bool BlackJack();
	bool Under(int a);
	int BestScore();
	bool MustHit();
	bool Busted();
	void ClearHand();
};

#endif // !_HAND_H