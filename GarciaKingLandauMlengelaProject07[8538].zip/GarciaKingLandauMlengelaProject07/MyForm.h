/****************************************************************
* Programmers: Aaron Garcia, Carrah King, Mayer Landau, Daudi Mlengela,
* Email: agarcia1091@cnm.edu, aking22@cnm.edu, mlandau1@cnm.edu, dmlengela@cnm.edu
* Project 07: Black Jack
* File: MyForm.h
*****************************************************************/

#include "Game.h"


#pragma once
namespace GarciaKingLandauMlengelaP07 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;

	Game game;

	/// <summary>
	/// Summary for MyForm
	/// </summary>
	public ref class MyForm : public System::Windows::Forms::Form
	{
	public:
		MyForm(void)
		{
			InitializeComponent();
			lblHitOrStayButtons->Visible = false;
			btnHit->Visible = false;
			btnStay->Visible = false;
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::MenuStrip^ menuStrip1;
	protected:
	private: System::Windows::Forms::ToolStripMenuItem^ gAMERULESToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^ rULESToolStripMenuItem;
	private: System::Windows::Forms::Label^ lblHeader;
	private: System::Windows::Forms::Label^ lblPlaceBet;
	private: System::Windows::Forms::Button^ btnBet;
	private: System::Windows::Forms::Button^ btnHit;
	private: System::Windows::Forms::Button^ btnStay;
	private: System::Windows::Forms::TextBox^ boxPlayerHand;
	private: System::Windows::Forms::Label^ lblHandLabel;
	private: System::Windows::Forms::TextBox^ boxDealerHand;
	private: System::Windows::Forms::Label^ lblDealerHandLabel;
	private: System::Windows::Forms::TextBox^ boxStatus;
	private: System::Windows::Forms::Button^ btnPlayAgain;
	private: System::Windows::Forms::Button^ btnQuit;
	private: System::Windows::Forms::Label^ lblHitOrStayButtons;

	private: System::Windows::Forms::TextBox^ boxBet;


	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container^ components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->menuStrip1 = (gcnew System::Windows::Forms::MenuStrip());
			this->gAMERULESToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->rULESToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->lblHeader = (gcnew System::Windows::Forms::Label());
			this->lblPlaceBet = (gcnew System::Windows::Forms::Label());
			this->btnBet = (gcnew System::Windows::Forms::Button());
			this->btnHit = (gcnew System::Windows::Forms::Button());
			this->btnStay = (gcnew System::Windows::Forms::Button());
			this->boxPlayerHand = (gcnew System::Windows::Forms::TextBox());
			this->lblHandLabel = (gcnew System::Windows::Forms::Label());
			this->boxDealerHand = (gcnew System::Windows::Forms::TextBox());
			this->lblDealerHandLabel = (gcnew System::Windows::Forms::Label());
			this->boxStatus = (gcnew System::Windows::Forms::TextBox());
			this->btnPlayAgain = (gcnew System::Windows::Forms::Button());
			this->btnQuit = (gcnew System::Windows::Forms::Button());
			this->lblHitOrStayButtons = (gcnew System::Windows::Forms::Label());
			this->boxBet = (gcnew System::Windows::Forms::TextBox());
			this->menuStrip1->SuspendLayout();
			this->SuspendLayout();
			// 
			// menuStrip1
			// 
			this->menuStrip1->BackColor = System::Drawing::Color::DarkOliveGreen;
			this->menuStrip1->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(1) { this->gAMERULESToolStripMenuItem });
			this->menuStrip1->Location = System::Drawing::Point(0, 0);
			this->menuStrip1->Name = L"menuStrip1";
			this->menuStrip1->Padding = System::Windows::Forms::Padding(7, 2, 0, 2);
			this->menuStrip1->Size = System::Drawing::Size(887, 24);
			this->menuStrip1->TabIndex = 0;
			this->menuStrip1->Text = L"menuStrip1";
			// 
			// gAMERULESToolStripMenuItem
			// 
			this->gAMERULESToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(1) { this->rULESToolStripMenuItem });
			this->gAMERULESToolStripMenuItem->ForeColor = System::Drawing::Color::Gold;
			this->gAMERULESToolStripMenuItem->Name = L"gAMERULESToolStripMenuItem";
			this->gAMERULESToolStripMenuItem->Size = System::Drawing::Size(88, 20);
			this->gAMERULESToolStripMenuItem->Text = L"GAME RULES";
			this->gAMERULESToolStripMenuItem->Click += gcnew System::EventHandler(this, &MyForm::gAMERULESToolStripMenuItem_Click);
			// 
			// rULESToolStripMenuItem
			// 
			this->rULESToolStripMenuItem->Name = L"rULESToolStripMenuItem";
			this->rULESToolStripMenuItem->Size = System::Drawing::Size(107, 22);
			this->rULESToolStripMenuItem->Text = L"RULES";
			// 
			// lblHeader
			// 
			this->lblHeader->AutoSize = true;
			this->lblHeader->BackColor = System::Drawing::Color::DarkKhaki;
			this->lblHeader->Font = (gcnew System::Drawing::Font(L"Courier New", 14.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->lblHeader->Location = System::Drawing::Point(172, 24);
			this->lblHeader->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->lblHeader->Name = L"lblHeader";
			this->lblHeader->Size = System::Drawing::Size(582, 88);
			this->lblHeader->TabIndex = 1;
			this->lblHeader->Text = L"Welcome to the C++ BlackJack Table!\r\nYou will begin with $1000 for your gambling "
				L"pleasure\r\n(don\'t spend it all at once ;> )\r\nyou may view the rules by clicking o"
				L"n \"GAME RULES\"";
			this->lblHeader->TextAlign = System::Drawing::ContentAlignment::TopCenter;
			// 
			// lblPlaceBet
			// 
			this->lblPlaceBet->AutoSize = true;
			this->lblPlaceBet->BackColor = System::Drawing::Color::DarkKhaki;
			this->lblPlaceBet->Font = (gcnew System::Drawing::Font(L"Courier New", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->lblPlaceBet->Location = System::Drawing::Point(284, 327);
			this->lblPlaceBet->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->lblPlaceBet->Name = L"lblPlaceBet";
			this->lblPlaceBet->Size = System::Drawing::Size(208, 18);
			this->lblPlaceBet->TabIndex = 2;
			this->lblPlaceBet->Text = L"Type bet then PLACE:";
			// 
			// btnBet
			// 
			this->btnBet->BackColor = System::Drawing::Color::OliveDrab;
			this->btnBet->Font = (gcnew System::Drawing::Font(L"Courier New", 14.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btnBet->Location = System::Drawing::Point(329, 365);
			this->btnBet->Margin = System::Windows::Forms::Padding(4, 3, 4, 3);
			this->btnBet->Name = L"btnBet";
			this->btnBet->Size = System::Drawing::Size(130, 66);
			this->btnBet->TabIndex = 3;
			this->btnBet->Text = L"PLACE BET";
			this->btnBet->UseVisualStyleBackColor = false;
			this->btnBet->Click += gcnew System::EventHandler(this, &MyForm::btnBet_Click);
			// 
			// btnHit
			// 
			this->btnHit->BackColor = System::Drawing::Color::IndianRed;
			this->btnHit->Enabled = false;
			this->btnHit->Font = (gcnew System::Drawing::Font(L"Courier New", 14.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btnHit->Location = System::Drawing::Point(499, 281);
			this->btnHit->Name = L"btnHit";
			this->btnHit->Size = System::Drawing::Size(94, 64);
			this->btnHit->TabIndex = 4;
			this->btnHit->Text = L"HIT";
			this->btnHit->UseVisualStyleBackColor = false;
			this->btnHit->Visible = false;
			this->btnHit->Click += gcnew System::EventHandler(this, &MyForm::btnHit_Click);
			// 
			// btnStay
			// 
			this->btnStay->BackColor = System::Drawing::Color::DarkOrange;
			this->btnStay->Enabled = false;
			this->btnStay->Font = (gcnew System::Drawing::Font(L"Courier New", 14.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btnStay->Location = System::Drawing::Point(732, 281);
			this->btnStay->Name = L"btnStay";
			this->btnStay->Size = System::Drawing::Size(94, 64);
			this->btnStay->TabIndex = 5;
			this->btnStay->Text = L"STAY";
			this->btnStay->UseVisualStyleBackColor = false;
			this->btnStay->Visible = false;
			this->btnStay->Click += gcnew System::EventHandler(this, &MyForm::btnStay_Click);
			// 
			// boxPlayerHand
			// 
			this->boxPlayerHand->BackColor = System::Drawing::SystemColors::Info;
			this->boxPlayerHand->Location = System::Drawing::Point(12, 226);
			this->boxPlayerHand->Multiline = true;
			this->boxPlayerHand->Name = L"boxPlayerHand";
			this->boxPlayerHand->ReadOnly = true;
			this->boxPlayerHand->Size = System::Drawing::Size(185, 119);
			this->boxPlayerHand->TabIndex = 6;
			// 
			// lblHandLabel
			// 
			this->lblHandLabel->AutoSize = true;
			this->lblHandLabel->BackColor = System::Drawing::Color::DarkKhaki;
			this->lblHandLabel->Font = (gcnew System::Drawing::Font(L"Courier New", 12, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Underline)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->lblHandLabel->Location = System::Drawing::Point(30, 204);
			this->lblHandLabel->Name = L"lblHandLabel";
			this->lblHandLabel->Size = System::Drawing::Size(138, 18);
			this->lblHandLabel->TabIndex = 7;
			this->lblHandLabel->Text = L"Player\'s Hand";
			// 
			// boxDealerHand
			// 
			this->boxDealerHand->BackColor = System::Drawing::SystemColors::Info;
			this->boxDealerHand->Location = System::Drawing::Point(12, 450);
			this->boxDealerHand->Multiline = true;
			this->boxDealerHand->Name = L"boxDealerHand";
			this->boxDealerHand->ReadOnly = true;
			this->boxDealerHand->Size = System::Drawing::Size(184, 116);
			this->boxDealerHand->TabIndex = 8;
			// 
			// lblDealerHandLabel
			// 
			this->lblDealerHandLabel->AutoSize = true;
			this->lblDealerHandLabel->BackColor = System::Drawing::Color::DarkKhaki;
			this->lblDealerHandLabel->Font = (gcnew System::Drawing::Font(L"Courier New", 12, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Underline)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->lblDealerHandLabel->Location = System::Drawing::Point(30, 429);
			this->lblDealerHandLabel->Name = L"lblDealerHandLabel";
			this->lblDealerHandLabel->Size = System::Drawing::Size(138, 18);
			this->lblDealerHandLabel->TabIndex = 9;
			this->lblDealerHandLabel->Text = L"Dealer\'s Hand";
			// 
			// boxStatus
			// 
			this->boxStatus->AcceptsReturn = true;
			this->boxStatus->AcceptsTab = true;
			this->boxStatus->BackColor = System::Drawing::SystemColors::Info;
			this->boxStatus->Location = System::Drawing::Point(478, 372);
			this->boxStatus->Multiline = true;
			this->boxStatus->Name = L"boxStatus";
			this->boxStatus->ReadOnly = true;
			this->boxStatus->Size = System::Drawing::Size(397, 209);
			this->boxStatus->TabIndex = 10;
			// 
			// btnPlayAgain
			// 
			this->btnPlayAgain->BackColor = System::Drawing::Color::LightSeaGreen;
			this->btnPlayAgain->Font = (gcnew System::Drawing::Font(L"Courier New", 14.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btnPlayAgain->Location = System::Drawing::Point(315, 520);
			this->btnPlayAgain->Name = L"btnPlayAgain";
			this->btnPlayAgain->Size = System::Drawing::Size(144, 40);
			this->btnPlayAgain->TabIndex = 11;
			this->btnPlayAgain->Text = L"PLAY AGAIN";
			this->btnPlayAgain->UseVisualStyleBackColor = false;
			this->btnPlayAgain->Click += gcnew System::EventHandler(this, &MyForm::btnPlayAgain_Click);
			// 
			// btnQuit
			// 
			this->btnQuit->BackColor = System::Drawing::Color::Brown;
			this->btnQuit->Font = (gcnew System::Drawing::Font(L"Courier New", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btnQuit->Location = System::Drawing::Point(761, 27);
			this->btnQuit->Name = L"btnQuit";
			this->btnQuit->Size = System::Drawing::Size(114, 53);
			this->btnQuit->TabIndex = 12;
			this->btnQuit->Text = L"LEAVE TABLE\r\n(QUIT)";
			this->btnQuit->UseVisualStyleBackColor = false;
			this->btnQuit->Click += gcnew System::EventHandler(this, &MyForm::btnQuit_Click);
			// 
			// lblHitOrStayButtons
			// 
			this->lblHitOrStayButtons->AutoSize = true;
			this->lblHitOrStayButtons->BackColor = System::Drawing::Color::DarkKhaki;
			this->lblHitOrStayButtons->Font = (gcnew System::Drawing::Font(L"Courier New", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->lblHitOrStayButtons->Location = System::Drawing::Point(436, 214);
			this->lblHitOrStayButtons->Name = L"lblHitOrStayButtons";
			this->lblHitOrStayButtons->Size = System::Drawing::Size(440, 64);
			this->lblHitOrStayButtons->TabIndex = 13;
			this->lblHitOrStayButtons->Text = L"HIT to deal another card (don\'t bust over 21!)\r\n\r\nSTAY to lock your cards in and "
				L"pass the turn to dealer\r\nPress HIT or STAY button \r\n";
			this->lblHitOrStayButtons->TextAlign = System::Drawing::ContentAlignment::TopCenter;
			this->lblHitOrStayButtons->Visible = false;
			// 
			// boxBet
			// 
			this->boxBet->BackColor = System::Drawing::SystemColors::Info;
			this->boxBet->Location = System::Drawing::Point(329, 344);
			this->boxBet->Name = L"boxBet";
			this->boxBet->Size = System::Drawing::Size(130, 20);
			this->boxBet->TabIndex = 14;
			// 
			// MyForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(7, 14);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::DarkOliveGreen;
			this->ClientSize = System::Drawing::Size(887, 592);
			this->Controls->Add(this->boxBet);
			this->Controls->Add(this->lblHitOrStayButtons);
			this->Controls->Add(this->btnQuit);
			this->Controls->Add(this->btnPlayAgain);
			this->Controls->Add(this->boxStatus);
			this->Controls->Add(this->lblDealerHandLabel);
			this->Controls->Add(this->boxDealerHand);
			this->Controls->Add(this->lblHandLabel);
			this->Controls->Add(this->boxPlayerHand);
			this->Controls->Add(this->btnStay);
			this->Controls->Add(this->btnHit);
			this->Controls->Add(this->btnBet);
			this->Controls->Add(this->lblPlaceBet);
			this->Controls->Add(this->lblHeader);
			this->Controls->Add(this->menuStrip1);
			this->Font = (gcnew System::Drawing::Font(L"Courier New", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->MainMenuStrip = this->menuStrip1;
			this->Margin = System::Windows::Forms::Padding(4, 3, 4, 3);
			this->Name = L"MyForm";
			this->Text = L"Group4P7 || BLACKJACK || CIS 2275 C++ PROGRAMMING II (R01) || ";
			this->Load += gcnew System::EventHandler(this, &MyForm::MyForm_Load);
			this->menuStrip1->ResumeLayout(false);
			this->menuStrip1->PerformLayout();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion

		//-----------------------------------------------------------
		//RULES
		//----------------------------------------------------------
	private: System::Void gAMERULESToolStripMenuItem_Click(System::Object^ sender, System::EventArgs^ e)
	{
		//shows game rules, builds the string, then using MessageBox to 
		//display a separate window with the string
		String^ mess = "Write the rules";
		MessageBox::Show(mess);

	}

    //-----------------------------------------------------------
	// BET BUTTON
	//-----------------------------------------------------------
	private: System::Void btnBet_Click(System::Object^ sender, System::EventArgs^ e)
	{
		//declare locals
		int bet{ 0 };
		double betNotInt{ 0.00 };
		bool isValidBet{ false };

		btnHit->Visible = false;
		btnStay->Visible = false;
		btnHit->Enabled = false;
		btnStay->Enabled = false;

		//Get bet from boxBet and convert to int, 
		betNotInt = Convert::ToDouble(boxBet->Text);
		bet = static_cast<int>(betNotInt + 0.5); // round double to nearest integer
		//Then set into bet -> game.SetBet, returning a bool, assigning into isValidBet.
		isValidBet = game.setBet(bet);

		//bool gate check for isValidBet to start game
		if (isValidBet) {
			// (optional, create boxStatus interval message: e.g. "Hands Dealt, Game started, deck shuffled"
			//call for initial deal
			game.InitialDeal();
			string gameStatus = "New hands being dealt.";
			boxStatus->Text = gcnew String(gameStatus.c_str());

			//display initial cards into player's hand box
			boxPlayerHand->Text = gcnew String(game.ShowPlayerHand().c_str());
			boxDealerHand->Text = gcnew String(game.ShowDealerHand(true).c_str());

			//check for blackjack from user  hand.BlackJack();
			if (game.IsBlackJack())
			{
				boxStatus->Text = gcnew String(game.PlayerWins().c_str());
				//update status if blackjack for: Player Wins
			}
			else
			{
				// Display the Hit Or Stay group
				lblHitOrStayButtons->Visible = true;
				btnHit->Visible = true;
				btnStay->Visible = true;
				btnHit->Enabled = true;
				btnStay->Enabled = true;
				// Hide the Place Bet group
				lblPlaceBet->Visible = false;
				boxBet->Visible = false;
				btnBet->Visible = false;
			}
		}
		else
		{
			string betValidity = "Not a valid bet. Please try again.";
			boxStatus->Text = gcnew String(betValidity.c_str());
		}
	}

	//-----------------------------------------------------------
    // HIT ME BUTTON
    //-----------------------------------------------------------
	private: System::Void btnHit_Click(System::Object^ sender, System::EventArgs^ e)
	{
		//clear status box
		boxStatus->Clear();
		boxStatus->ResetText();
		game.PlayerHits();
		//display players NEW hand in box hand.ShowHand();
		boxPlayerHand->Text = gcnew String(game.ShowPlayerHand().c_str());
		//bool gate check to see if player can continue(no bust, etc) hand.Busted();
		//if (game.PlayerContinues())
		//{	
		//}
		if (game.PlayerBusted())
		{
			boxDealerHand->Text = gcnew String(game.ShowDealerHand(false).c_str());
			string busted = "Player is busted.";
			boxStatus->Text = gcnew String(busted.c_str());
			boxStatus->Text += gcnew String(game.ShowResults().c_str());
		} 
	}

	//-----------------------------------------------------------
	//STAY BUTTON
	//-----------------------------------------------------------
	private: System::Void btnStay_Click(System::Object^ sender, System::EventArgs^ e)
	{
		btnHit->Visible = false;
		btnStay->Visible = false;
		btnHit->Enabled = false;
		btnStay->Enabled = false;
		boxStatus->Clear();
		boxStatus->ResetText();
		boxPlayerHand->Clear();
		boxPlayerHand->ResetText();
		string test1 = game.ShowPlayerHand();
		boxPlayerHand->Text = gcnew String(game.ShowPlayerHand().c_str());
		//dealer plays (draws till dealer can't hit with hand.MustHit(), checks blackjack.)
		//use while loop
		bool dealerContinue = true;
		while (dealerContinue)
		{
			dealerContinue = game.DealerContinues();
		}
		//update dealer hand box hand.ShowHand();
		string test2 = game.ShowDealerHand(false);
		boxDealerHand->Text = gcnew String(game.ShowDealerHand(false).c_str());

		//update status box game.ShowResults()
		//boxStatus->Text += gcnew String(game.DealerWins().c_str());
		boxStatus->Text = gcnew String(game.ShowResults().c_str());

	}

	//-----------------------------------------------------------
	// PLAY AGAIN
	//-----------------------------------------------------------
	private: System::Void btnPlayAgain_Click(System::Object^ sender, System::EventArgs^ e)
	{
		// Clear boxes
		//clear status box
		boxStatus->Clear();
		boxStatus->ResetText();
		boxPlayerHand->Clear();
		boxDealerHand->Clear();
		game.ClearHands();
		//reset buttons and label to invisible/visible 
		//replace place bet
		lblPlaceBet->Visible = true;
		btnBet->Visible = true;
		boxBet->Visible = true;
		

		//remove the Hit Or Stay group
		lblHitOrStayButtons->Visible = false;
		btnHit->Visible = false;
		btnStay->Visible = false;
		
	}

		   //-----------------------------------------------------------
		   //QUIT BUTTON
		   //-----------------------------------------------------------
	private: System::Void btnQuit_Click(System::Object^ sender, System::EventArgs^ e)
	{
		//end game with game.EndGame()
		game.EndGame();
		//then Application::exit()
		Application::Exit();
	}

	//-----------------------------------------------------------
	// FORM LOAD
	//-----------------------------------------------------------
	private: System::Void MyForm_Load(System::Object^ sender, System::EventArgs^ e)
	{
		//check if log file is open, game.IsLogOpened() display message boxStatus
		if (!(game.IsLogOpened()))
		{
			string noFileOpened = "No file written.";
			boxStatus->Text = gcnew String(noFileOpened.c_str());
		}		
	}

	};
}
